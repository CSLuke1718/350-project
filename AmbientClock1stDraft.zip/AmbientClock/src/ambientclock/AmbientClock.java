/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ambientclock;

import java.awt.geom.Rectangle2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Hashtable;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author Bryan Banuelos
 */
public class AmbientClock extends Application {
     //Creation of files to store guest and admin info for log in
    final File guestFile = new File("Guest.txt"); //MAKE SURE THE PATH IS CORRECT
    
    //Creates two different hashtable with guest and admin sing up credentials by reading file
    Hashtable<String, String> guestHT = new Hashtable();
    
    @Override
    public void start(Stage primaryStage) {
        javafx.geometry.Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
 
        //set Stage boundaries to the lower right corner of the visible bounds of the main screen
        primaryStage.setX(primaryScreenBounds.getMinX() + primaryScreenBounds.getWidth() - 400);
        primaryStage.setY(primaryScreenBounds.getMinY() + primaryScreenBounds.getHeight() - 300);
        primaryStage.setWidth(400);
        primaryStage.setHeight(300);
 
        Button btn = new Button();
        btn.setText("Log In!");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                userLogin(primaryStage);
            }
        });
        
        StackPane root = new StackPane();
        root.getChildren().add(btn);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Log In");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public void confirmLogIn(Stage primaryStage, String uname, String pword){
        
        System.out.println("Here");
        if (pword.equals("")){
            if (guestValidation(uname, pword)){
                //go to next screen
                wildfiresGuestView(primaryStage);
            }
            else{
                System.out.println("Invalid guest log in information");
            }
        }
    }

    public void userLogin(Stage primaryStage) {
        GridPane grid1 = new GridPane();
        //put 10 pixel padding around window
        grid1.setPadding(new Insets(10, 10, 10, 10));
        //add padding for each cell
        grid1.setVgap(8); //vertical padding
        grid1.setHgap(8); //horizontal padding
        
        //Log In Text
        Label logInText = new Label("LOG IN");
        GridPane.setConstraints(logInText, 0, 0);
        
        //username label
        Label nameLabel = new Label("Username:");
        GridPane.setConstraints(nameLabel, 0, 1);
        
        //username input
        TextField nameInput = new TextField();
        nameInput.setPromptText("username");
        GridPane.setConstraints(nameInput, 1, 1);
        
        //password label
        Label passLabel = new Label("Password:");
        GridPane.setConstraints(passLabel, 0, 2);
        
        //password input
        TextField passInput = new TextField();
        passInput.setPromptText("password");
        GridPane.setConstraints(passInput, 1, 2);
        
        Button loginButton = new Button("LOG IN");
        GridPane.setConstraints(loginButton, 0, 5);
        loginButton.setOnAction( e -> {
            confirmLogIn(primaryStage, nameInput.getText(), passInput.getText()
            );
                    });
        
        Label createText = new Label("Don't have an account?\n"
                + "Create an Account");
        GridPane.setConstraints(createText, 0, 6);
        
        Button signUpButton = new Button("SIGN UP");
        GridPane.setConstraints(signUpButton, 0, 7);
        signUpButton.setOnAction(e -> {
            createUser(primaryStage);
        
        });
        
        grid1.getChildren().addAll(logInText, nameLabel, nameInput, passLabel, passInput,
                loginButton, createText, signUpButton);
        
        

        
        Scene scene = new Scene(grid1, 350, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
        }
    public void createUser(Stage primaryStage) {
        
        GridPane grid1 = new GridPane();
        //put 10 pixel padding around window
        grid1.setPadding(new Insets(10, 10, 10, 10));
        //add padding for each cell
        grid1.setVgap(8); //vertical padding
        grid1.setHgap(8); //horizontal padding
        

       
        StackPane createUserLayout = new StackPane();
        
        Label createUser = new Label("Create New User");
        GridPane.setConstraints(createUser, 0, 0);
        
        //first name label in topleft of grid
        Label firstNameLabel = new Label("First Name:");
        GridPane.setConstraints(firstNameLabel, 0, 1);
        
        //first name input to the right of label
        TextField firstNameInput = new TextField();
        firstNameInput.setPromptText("first name");
        GridPane.setConstraints(firstNameInput, 1, 1);
        
        //last name label
        Label lastNameLabel = new Label("Last Name:");
        GridPane.setConstraints(lastNameLabel, 0, 2);
        
        //last name input
        TextField lastNameInput = new TextField();
        lastNameInput.setPromptText("last name");
        GridPane.setConstraints(lastNameInput, 1, 2);
        
        //username label
        Label usernameLabel = new Label("Username:");
        GridPane.setConstraints(usernameLabel, 0, 3);
        
        //username input
        TextField usernameInput = new TextField();
        usernameInput.setPromptText("username");
        GridPane.setConstraints(usernameInput, 1, 3);
        
        //password label
        Label passwordLabel = new Label("Password:");
        GridPane.setConstraints(passwordLabel, 0, 4);
        
        //password input
        TextField passwordInput = new TextField();
        passwordInput.setPromptText("password");
        GridPane.setConstraints(passwordInput, 1, 4);
        
        //confirm password label
        Label confirmPasswordLabel = new Label("Confirm Password:");
        GridPane.setConstraints(confirmPasswordLabel, 0, 5);
        
        //confirm password input
        TextField confirmPasswordInput = new TextField();
        confirmPasswordInput.setPromptText("password");
        GridPane.setConstraints(confirmPasswordInput, 1, 5);
      

        
        Button createAccount = new Button("CREATE ACCOUNT");
        createAccount.setOnAction(e -> {
            confirmInputs(primaryStage, firstNameInput.getText(), lastNameInput.getText(), 
            usernameInput.getText(), passwordInput.getText(), confirmPasswordInput.getText());
        });
       
        GridPane.setConstraints(createAccount, 0, 8);
        
        //button to return back to Log In screen
        Button goBackButton = new Button("GO BACK");
        GridPane.setConstraints(goBackButton, 1, 8);
        goBackButton.setOnAction( e -> {
            userLogin(primaryStage);
        });
        
        
        grid1.getChildren().addAll(createUser, firstNameLabel, firstNameInput, 
                lastNameLabel, lastNameInput, usernameLabel, usernameInput, 
                passwordLabel, passwordInput, confirmPasswordLabel, 
                confirmPasswordInput, createAccount, goBackButton);
        
 
        createUserLayout.getChildren().addAll(grid1);
        Scene userCreateScene = new Scene(createUserLayout, 350, 300);
        primaryStage.setScene(userCreateScene);
        
    }
    public void confirmInputs(Stage primaryStage, String fname, String lname, 
            String uname, String pword, String pword2){
        //creates guest or admin and adds them as object to hash table
        if (pword.equals(pword2)){
            createGuest(fname, lname, uname, pword);
            guestHT = readFromGuestFile();
            accountCreation(primaryStage);
        }
        else {
            Alert alert1 = new Alert(Alert.AlertType.ERROR, "Passwords do not match!");
                alert1.show();
        }
    }
    public void createGuest(String guestFN, String guestLN, String guestUN, String guestPW){
        Guest guest_1 = new Guest(guestFN, guestLN, guestUN, guestPW);

        try {
            guest_1.addToGuestFile(guest_1.getUsername(), guest_1.getPassword(), guestFile);
                    }
        catch (Exception e){
            System.out.println(e);
        }
    }
    public Hashtable<String, String> readFromGuestFile() {
        Hashtable<String, String> GHT = new Hashtable<>();
        //Try clause that will read from CSV file and add to hashtable
        try{
            String line;
            BufferedReader br = new BufferedReader(new FileReader(guestFile));

            while((line = br.readLine()) != null){       //while loop resets array values
                String[] values = line.split(","); //add values from line separated by commas to array
                GHT.put(values[0], values[1]);          //add array[0] as key and array[1] as value
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return GHT;
    }
    public boolean guestValidation(String username, String password){
        if (guestHT.containsKey(username)){
            if (guestHT.get(username).equals(password)){
                return true;
            }
            else{
                return false;
            }
        }
        return false;
    }
    public void accountCreation(Stage primaryStage) {
        
        GridPane tyGrid = new GridPane();
        tyGrid.setPadding(new Insets(10, 10, 10, 10)); //add padding for each cell
        tyGrid.setVgap(50); //vertical padding
        tyGrid.setHgap(8); //horizontal padding
        
        //Thanks for creating an accout Label
        Label thanks = new Label("Thanks for creating an account!!!");
        GridPane.setConstraints(thanks, 0, 0);
        
        Button back = new Button("RETURN TO LOG IN PAGE");
        GridPane.setConstraints(back, 0, 1);
        back.setOnAction( e -> {
                userLogin(primaryStage);
        });
        
        tyGrid.getChildren().addAll(thanks, back);
        
        StackPane thankYouScreen = new StackPane();
        thankYouScreen.getChildren().addAll(tyGrid);
        Scene sceneThankYou = new Scene(thankYouScreen, 200, 200);
        primaryStage.setScene(sceneThankYou);
        }
     public void wildfiresGuestView(Stage primaryStage) {
        /*
        *  GUEST VIEW SCREEN
        */
        Button goBackButton = new Button("GO BACK");
  
        
        //button to return back to Log In screen
        goBackButton.setOnAction( e -> {
            userLogin(primaryStage);
        });
        primaryStage.setOnCloseRequest(e -> {
        });

        primaryStage.setTitle("Timer Countdown");
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
