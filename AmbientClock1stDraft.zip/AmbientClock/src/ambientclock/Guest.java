/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ambientclock;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Lydia Manu, Vinicius Molz, Bryan Branuelos
 */
public class Guest implements User {
    private String GuestFirstName;
    private String GuestLastName;
    private String GuestUsername;
    private String GuestPassword;

    public Guest(String GuestFirstName, String GuestLastName,
                 String GuestUsername, String GuestPassword) {
        this.GuestFirstName = GuestFirstName;
        this.GuestLastName = GuestLastName;
        this.GuestUsername = GuestUsername;
        this.GuestPassword = GuestPassword;
    }

    @Override
    public String getFirstName() {
        return GuestFirstName;
    }

    @Override
    public String getLastName() {
        return GuestLastName;
    }

    @Override
    public String getUsername() {
        return GuestUsername;
    }

    @Override
    public String getPassword() {
        return GuestPassword;
    }
    @Override
    public String toString(){
        return ("First Name: " + GuestFirstName +
                "\nlast Name: " + GuestLastName +
                "\nUsername: " + GuestUsername +
                "\nPassword: " + GuestPassword);
    }

    public void addToGuestFile(String username, String password, File f) throws IOException{
        FileWriter fw = new FileWriter(f, true);
        try {
            fw.write(username + ",");
            fw.write(password+ "\n");
            fw.close();
        }
        catch(Exception e){
            System.out.println("A problem had occurred! Please, try again");
        }
    }
}
