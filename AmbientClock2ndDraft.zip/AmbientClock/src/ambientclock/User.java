/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ambientclock;

/**
 *
 * @author Bryan Banuelos
 */
public interface User {

    public String getUsername();
        //returns user's Username

    public String toString();
        //toString method summarizing user's information
}

